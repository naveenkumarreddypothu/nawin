/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
 */

/**
 * Define Global Variables
 *
 */
 //Defining Global variable
let sections = Array.from(document.getElementsByTagName('section')),navigationList = document.querySelector('#navbar__list');
/**
  * End Global Variables
  * Start Helper Functions
  *
  */

 
//forming list
for(let i of sections){ 
function list() {
    const menu ="menu",li = document.createElement('li'),linkTag=document.createElement('a');
    linkTag.textContent=i.id;
    linkTag.textContent=i.dataset.nav;
    li.setAttribute("class",menu);
    li.setAttribute("data", i.id);
    linkTag.setAttribute("href","#"+i.id);
    linkTag.setAttribute("class", i.id);
    li.appendChild(linkTag);
    navigationList.appendChild(li);
 }
list();
}

//active class
activeState=()=>{
for (const x of sections) {
    const dim = x.getBoundingClientRect(); 
   {
    if (dim.top <= 150 && dim.bottom >= 150) {
      x.classList.add("your-active-class");
    } else {
      x.classList.remove("your-active-class");
    }
  }
}
document.addEventListener('scroll',activeState);
/**
  * End Helper Functions
  * Begin Main Functions  set_active(event,anch_temp)
  *
  */

 /**
  * this function will add li items to unordered list
  */


//smooth behaviour
function scrollIt() {
 document.querySelectorAll("a").forEach(a=>{
    a.addEventListener("click",(e)=>{
    e.preventDefault();
    let id=a.getAttribute("class");
    document.getElementById(id).scrollIntoView({behavior:"smooth"});
   });
 });
 }
 scrollIt();
 
 
